/* CULTIVO HIDROPONICO 
 * 
 * PROYECTO FINAL DE SEMESTRE
 * 
 * ELECTRONUCA DIGITAL II
 * 
 * Author: Maria Camila Lopez - 2420191074
 *         Juan Camilo Triana - 2420191025
 * Docente: 
 *         Harold Murcia 
 * 
 * Created on 8 de mayo de 2021.
 */
// PIC16F15244 


#pragma config FEXTOSC = OFF    // External Oscillator Mode Selection bits (Oscillator not enabled)
#pragma config RSTOSC = HFINTOSC_32MHZ// Power-up Default Value for COSC bits (HFINTOSC (32 MHz))
#pragma config CLKOUTEN = OFF   // Clock Out Enable bit (CLKOUT function is disabled; I/O function on RA4)
#pragma config VDDAR = HI       // VDD Range Analog Calibration Selection bit (Internal analog systems are calibrated for operation between VDD = 2.3V - 5.5V)

// CONFIG2
#pragma config MCLRE = INTMCLR  // Master Clear Enable bit (If LVP = 0, MCLR pin is MCLR; If LVP = 1, RA3 pin function is MCLR)
#pragma config PWRTS = PWRT_OFF // Power-up Timer Selection bits (PWRT is disabled)
#pragma config WDTE = OFF     // WDT Operating Mode bits (WDT disabled; SEN is ignored)
#pragma config BOREN = ON       // Brown-out Reset Enable bits (Brown-out Reset Enabled, SBOREN bit is ignored)
#pragma config BORV = LO        // Brown-out Reset Voltage Selection bit (Brown-out Reset Voltage (VBOR) set to 1.9V)
#pragma config PPS1WAY = ON     // PPSLOCKED One-Way Set Enable bit (The PPSLOCKED bit can be cleared and set only once in software)
#pragma config STVREN = ON      // Stack Overflow/Underflow Reset Enable bit (Stack Overflow or Underflow will cause a reset)

// CONFIG3

// CONFIG4
#pragma config BBSIZE = BB512   // Boot Block Size Selection bits (512 words boot block size)
#pragma config BBEN = OFF       // Boot Block Enable bit (Boot Block is disabled)
#pragma config SAFEN = OFF      // SAF Enable bit (SAF is disabled)
#pragma config WRTAPP = OFF     // Application Block Write Protection bit (Application Block is not write-protected)
#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot Block is not write-protected)
#pragma config WRTC = OFF       // Configuration Registers Write Protection bit (Configuration Registers are not write-protected)
#pragma config WRTSAF = OFF     // Storage Area Flash (SAF) Write Protection bit (SAF is not write-protected)
#pragma config LVP = OFF       // Low Voltage Programming Enable bit (Low Voltage programming enabled. MCLR/Vpp pin function is MCLR. MCLRE Configuration bit is ignored.)

// CONFIG5
#pragma config CP = OFF         // User Program Flash Memory Code Protection bit (User Program Flash Memory code protection is disabled)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>


#include <stdlib.h>
#include <stdio.h>
#include <pic16f15244.h>



#ifndef CLOCK_H
#define	CLOCK_H

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 32000000
#endif

void CLOCK_Initialize(void);

#endif	/* CLOCK_H */
/**
 End of File
*/
#include "I2C_LCD.h"
float lec_Humed; 
float lec_Temp=0;
const unsigned char SHumed=0b000101;
const unsigned char STemp=0b000001;
const unsigned char Valvula=0b00000001;
const unsigned char BOMBA=0b00000010;
const unsigned char nivel=0b00001100;
char Aviso = 0;

int*Estado;

// Vo_A_TEMP.
// Conversion de Voltios a Temperatura 
const float Vo_A_TEMP=100.0*5.0/1023.0;
// Vo_A_HUM.
//Conversion de Voltios a Humedad
const float Vo_A_HUM=1.0*5.0/1023.0;


// Limite de minima Temperatura
const int Max_Temp = 26;
// Limite de maxima temperatura 
const int Min_Humed = 2;

// Variable donde se mostrara en texto la Temperatura
char*Tex_Temp;
// Variable donde se mostrara en texto la Humedad
char*Tex_Humd;
//------------------------------------------------------------------------------
void Star_ADC()
{
    ADCON0 = 0b00000001; 
    ADCON1 = 0b11100000;
}
//------------------------------------------------------------------------------
unsigned int Leer_ADC(unsigned char Ruta)
{ 
    ADCON0 &=0X3;
    
    ADCON0 |=Ruta<<2;
    
    __delay_us(30);
    //GO_nDONE=1;

    ADCON0 |=1<<1;
    
    while(ADCON0 & 0x2);
    
    return ((ADRESH<<8)+ADRESL);
}
//------------------------------------------------------------------------------
void Variables()
{
    Tex_Temp= ftoa(lec_Temp, Estado);
    Tex_Temp[4] = 0x0;
    LCD_Set_Cursor(1, 10); 
    LCD_Write_String(Tex_Temp);  
    
    Tex_Humd= ftoa(lec_Humed, Estado);
    Tex_Humd[4] = 0x0;
    LCD_Set_Cursor(2, 3); 
    LCD_Write_String(Tex_Humd);
}
//------------------------------------------------------------------------------
void Texto()
{
    LCD_Write_String("T=");
    LCD_Set_Cursor(1, 8);
    LCD_Write_String("H=");
    LCD_Set_Cursor(2, 1);
}
//------------------------------------------------------------------------------
void Inicio()
{
    I2C_Master_Init(); 
    LCD_Init(0x4E);
    Texto();     
}
//------------------------------------------------------------------------------
void Sensores()
{
    //lectura sensores digitales
    //Vo_A_TEMP = 100.0
    //Vo_A_HUM = 1.0
    //lectura analogicos 
    lec_Humed=Vo_A_HUM*(Star_ADC(SHumed)); 
    
    lec_Temp=Vo_A_TEMP*(Star_ADC(STemp)); 
    
}
//------------------------------------------------------------------------------
void TanqueLLeno()
{
    while(Aviso==1)
    {
        if((PORTC & nivel)==0x0) 
        {
            Aviso=0;
            PORTC|= Valvula;                                                    // Apagar Valvula
            LCD_Set_Cursor(2,8);
            LCD_Write_String("Tanq_lleno");
            __delay_ms(1000);
        }
    }
}
//------------------------------------------------------------------------------
void TanqueVacio()
{    
    PORTCbits.RC7=PORTCbits.RC2;
    PORTCbits.RC6=PORTCbits.RC3;
    if((PORTC & nivel)==0b00001100)
    {
        PORTC&=~Valvula;                                                        // Encender Valvula
        PORTC|=BOMBA;                                                           // Apagar Bomba
        Aviso=1;
        LCD_Set_Cursor(2,8);
        LCD_Write_String("Llenando");
    }
}
//------------------------------------------------------------------------------
void Riego()
{
    if((lec_Humed >= Min_Humed) && (lec_Temp >= Max_Temp) )
    {
        PORTC&=~BOMBA;                                                          // Encender Bomba
        LCD_Set_Cursor(2,8);
        LCD_Write_String("Regando");
    }
    else
    {
        PORTC|=BOMBA;
        LCD_Set_Cursor(2,8);
        LCD_Write_String("Estable");       
    }
}
//------------------------------------------------------------------------------
void main(void) {
    TRISC = nivel;                                                                // configurar pines I/O
    ANSELC = 0x00;
    
    PORTC|= 0b11110011;
    __delay_ms(600);
    PORTC&= ~0b11110000;
    
    
    TRISB = 0b01010000;
    TRISA = 0b111111;
    ANSELA = 0xff;
    
    Star_ADC();
    Inicio();

    LCD_Set_Cursor(1, 1);
    LCD_Write_String("Tu");
    __delay_ms(1000);
    LCD_Set_Cursor(1, 2);
    LCD_Write_String("Tranquilo");
    __delay_ms(1000);
  
}

